# Resume Builder — Upgraded (Creative Bold default)

## Features
- Multiple templates: Creative (default), Classic, Professional
- Themes: Professional, Modern, Dark
- Full editors: Profile, Experience, Education, Projects, Skills
- Drag & drop reordering for experiences (HTML5)
- Auto-save to browser localStorage
- Export: HTML and Print-to-PDF
- Simple ATS job-description matcher (client-side)

## Run
1. `npm install`
2. `npm run dev`
3. Open the URL shown by Vite (usually http://localhost:5173)

## Notes
- This is a demo frontend-only implementation. LLM/Backend features are not included.
- For DOCX export or server PDF generation, we can add a backend in the next step.
