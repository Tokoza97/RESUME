import React, { useState } from 'react'
export default function ATSPanel({ onMatch }){
  const [jd, setJd] = useState('')
  return (
    <div>
      <textarea className="input" placeholder="Paste job description to match" value={jd} onChange={e=>setJd(e.target.value)} />
      <div style={{marginTop:8}}><button className="btn" onClick={()=> onMatch(jd)}>Match</button></div>
    </div>
  )
}
