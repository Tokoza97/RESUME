
// All sample pre-filled content removed so the resume loads empty

import React, { useEffect, useState, useRef } from 'react'
import TemplateCreative from '../templates/Creative'
import TemplateClassic from '../templates/Classic'
import TemplateProfessional from '../templates/Professional'
import ATSPanel from './ATSPanel'

const uid = (p='') => Date.now().toString(36) + Math.random().toString(36).slice(2,6) + p

export default function Builder({ defaultTemplate='creative' }){
  const [name,setName] = useState('')
  const [title,setTitle] = useState('')
  const [contact,setContact] = useState('')
  const [summary,setSummary] = useState('')
  const [skills,setSkills] = useState('')

  // EMPTY default sections
  const [experiences,setExperiences] = useState([])
  const [education,setEducation] = useState([])
  const [projects,setProjects] = useState([])

  const [template,setTemplate] = useState(defaultTemplate)
  const [layout,setLayout] = useState('creative')
  const previewRef = useRef(null)

  useEffect(() => {
    const raw = localStorage.getItem('resume_upgraded_v1')
    if(raw){
      const parsed = JSON.parse(raw)
      setName(parsed.name || '')
      setTitle(parsed.title || '')
      setContact(parsed.contact || '')
      setSummary(parsed.summary || '')
      setSkills(parsed.skills || '')
      setExperiences(parsed.experiences || [])
      setEducation(parsed.education || [])
      setProjects(parsed.projects || [])
      setTemplate(parsed.template || defaultTemplate)
      setLayout(parsed.layout || 'creative')
    }
  },[])

  // autosave debounce
  useEffect(()=>{
    const t=setTimeout(()=>{
      localStorage.setItem('resume_upgraded_v1', JSON.stringify({
        name,title,contact,summary,skills,experiences,education,projects,template,layout
      }))
    },700)
    return ()=> clearTimeout(t)
  },[name,title,contact,summary,skills,experiences,education,projects,template,layout])

  function addExperience(){
    setExperiences(prev => [...prev, { id:uid('e'), title:'', company:'', start:'', end:'', bullets:[''] }])
  }
  function updateExperience(id, patch){
    setExperiences(prev => prev.map(x => x.id===id ? { ...x, ...patch } : x))
  }
  function removeExperience(id){
    setExperiences(prev => prev.filter(x => x.id!==id))
  }
  function addBullet(id){
    setExperiences(prev => prev.map(x => x.id===id ? { ...x, bullets:[...x.bullets,''] } : x))
  }
  function updateBullet(id, idx, val){
    setExperiences(prev => prev.map(x => x.id===id ? { ...x, bullets:x.bullets.map((b,i)=> i===idx? val : b ) } : x))
  }

  function exportHTML(){
    const content = previewRef.current?.innerHTML || ''
    const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name} - Resume</title><style>body{font-family:Inter,Arial,sans-serif;padding:20px}</style></head><body>${content}</body></html>`
    const blob = new Blob([html], { type:'text/html' })
    const url = URL.createObjectURL(blob)
    const a=document.createElement('a')
    a.href=url
    a.download=`${name||'resume'}.html`
    a.click()
    URL.revokeObjectURL(url)
  }

  function exportPDF(){
    window.print()
  }

  return (
    <div className="builder-container">
      <ATSPanel />

      <div className="left-panel">

        <div className="card p-4">
          <h3 className="section-title">Basic Info</h3>
          <input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Full Name" />
          <input className="input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title (e.g. Software Developer)" />
          <input className="input" value={contact} onChange={e=>setContact(e.target.value)} placeholder="Contact Info" />
        </div>

        <div className="card p-4">
          <h3 className="section-title">Professional Summary</h3>
          <textarea className="input" value={summary} onChange={e=>setSummary(e.target.value)} placeholder="Write a short summary..." />
        </div>

        <div className="card p-4">
          <h3 className="section-title">Skills</h3>
          <textarea className="input" value={skills} onChange={e=>setSkills(e.target.value)} placeholder="e.g. JavaScript, React, Node.js" />
        </div>

        <div className="card p-4">
          <h3 className="section-title">Experience</h3>
          {experiences.map(exp => (
            <div key={exp.id} className="exp-block">
              <input className="input" value={exp.title} onChange={e=>updateExperience(exp.id,{title:e.target.value})} placeholder="Job Title" />
              <input className="input" value={exp.company} onChange={e=>updateExperience(exp.id,{company:e.target.value})} placeholder="Company" />
              <div style={{display:'flex', gap:6}}>
                <input className="input" value={exp.start} onChange={e=>updateExperience(exp.id,{start:e.target.value})} placeholder="Start" />
                <input className="input" value={exp.end} onChange={e=>updateExperience(exp.id,{end:e.target.value})} placeholder="End" />
              </div>

              <div className="bullets">
                {exp.bullets.map((b,i)=>(
                  <input key={i} className="input" value={b} onChange={e=>updateBullet(exp.id,i,e.target.value)} placeholder={`Bullet ${i+1}`} />
                ))}
                <button className="btn small" onClick={()=>addBullet(exp.id)}>+ Add Bullet</button>
              </div>

              <button className="btn btn-danger small" onClick={()=>removeExperience(exp.id)}>Remove</button>
            </div>
          ))}
          <button className="btn" onClick={addExperience}>+ Add Experience</button>
        </div>

        <div className="card p-4">
          <h3 className="section-title">Projects</h3>
          {projects.map(pr => (
            <div key={pr.id} className="project-block">
              <input className="input" value={pr.name} onChange={e=> setProjects(prev=>prev.map(x=>x.id===pr.id?{...x,name:e.target.value}:x))} placeholder="Project Name" />
              <textarea className="input" value={pr.desc} onChange={e=> setProjects(prev=>prev.map(x=>x.id===pr.id?{...x,desc:e.target.value}:x))} placeholder="Short description" />
              <input className="input" value={pr.link} onChange={e=> setProjects(prev=>prev.map(x=>x.id===pr.id?{...x,link:e.target.value}:x))} placeholder="Link (optional)" />
            </div>
          ))}
          <button className="btn" onClick={()=> setProjects(prev=> [...prev, { id:uid('p'), name:'', desc:'', link:'' }]) }>+ Add Project</button>
        </div>

        <div className="card p-4">
          <h3 className="section-title">Education</h3>
          {education.map(ed => (
            <div key={ed.id} style={{display:'flex', gap:8, marginBottom:8}}>
              <input className="input" value={ed.school} onChange={e=> setEducation(prev=> prev.map(x=> x.id===ed.id? {...x, school:e.target.value}:x))} placeholder="School" />
              <input className="input" style={{width:220}} value={ed.degree} onChange={e=> setEducation(prev=> prev.map(x=> x.id===ed.id? {...x, degree:e.target.value}:x))} placeholder="Degree" />
              <input className="input" style={{width:120}} value={ed.years} onChange={e=> setEducation(prev=> prev.map(x=> x.id===ed.id? {...x, years:e.target.value}:x))} placeholder="Years" />
            </div>
          ))}
          <button className="btn" onClick={()=> setEducation(prev=> [...prev, { id:uid('ed'), school:'', degree:'', years:'' }]) }>+ Add Education</button>
        </div>

        <div className="card p-4 no-print">
          <h3 className="section-title">Export & Tools</h3>
          <div style={{display:'flex', gap:8}}>
            <button className="btn btn-primary" onClick={exportHTML}>Export HTML</button>
            <button className="btn" onClick={exportPDF}>Export PDF</button>
            <button className="btn" onClick={()=> navigator.clipboard.writeText(JSON.stringify({name,title,contact,summary,skills,experiences,education,projects},null,2))}>Copy JSON</button>
          </div>
        </div>

      </div>

      <aside className="card p-4">
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div>
            <h2 style={{margin:0}}>{name}</h2>
            <div className="small">{title} · {contact}</div>
          </div>
          <div>
            <select className="input" value={layout} onChange={e=>setLayout(e.target.value)} style={{minWidth:140}}>
              <option value="creative">Creative Bold</option>
              <option value="classic">Classic</option>
              <option value="professional">Professional</option>
            </select>
          </div>
        </div>

        <div ref={previewRef} id="preview" style={{marginTop:12}} className="preview-frame">
          {layout==='creative' && <TemplateCreative name={name} title={title} contact={contact} summary={summary} skills={skills} experiences={experiences} education={education} projects={projects} />}
          {layout==='classic' && <TemplateClassic name={name} title={title} contact={contact} summary={summary} skills={skills} experiences={experiences} education={education} projects={projects} />}
          {layout==='professional' && <TemplateProfessional name={name} title={title} contact={contact} summary={summary} skills={skills} experiences={experiences} education={education} projects={projects} />}
        </div>

      </aside>
    </div>
    )
}
