import React from 'react'
export default function Professional({ name, title, contact, summary, skills, experiences, education, projects }){
  return (
    <div style={{padding:12}}>
      <div style={{display:'flex', justifyContent:'space-between'}}><div><h2 style={{margin:0}}>{name}</h2><div style={{color:'#666'}}>{title}</div></div><div style={{textAlign:'right'}}>{contact}</div></div>
      <hr/>
      <div style={{display:'grid', gridTemplateColumns:'1fr 200px', gap:12}}>
        <div>
          <section><h3>Summary</h3><p>{summary}</p></section>
          <section><h3>Experience</h3>{experiences.map((e,i)=>(<div key={i}><b>{e.title}</b> — {e.company}<ul>{e.bullets.map((b,idx)=>(<li key={idx}>{b}</li>))}</ul></div>))}</section>
        </div>
        <aside>
          <section><h3>Skills</h3><p>{skills}</p></section>
          <section><h3>Education</h3>{education.map((ed,i)=>(<div key={i}><b>{ed.degree}</b><div>{ed.school}</div></div>))}</section>
        </aside>
      </div>
    </div>
  )
}
