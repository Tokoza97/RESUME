import React from 'react'
export default function Classic({ name, title, contact, summary, skills, experiences, education, projects }){
  return (
    <div style={{padding:12, fontFamily:'serif'}}>
      <h1 style={{margin:0}}>{name}</h1>
      <div style={{color:'#666'}}>{title} · {contact}</div>
      <hr/>
      <section><h3>Summary</h3><p>{summary}</p></section>
      <section><h3>Experience</h3>{experiences.map((e,i)=>(<div key={i}><b>{e.title}</b> — {e.company}<ul>{e.bullets.map((b,idx)=>(<li key={idx}>{b}</li>))}</ul></div>))}</section>
      <section><h3>Skills</h3><p>{skills}</p></section>
    </div>
  )
}
