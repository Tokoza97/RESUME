import React from 'react'
export default function Creative({ name, title, contact, summary, skills, experiences, education, projects }){
  return (
    <div style={{padding:12}}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:12}}>
        <div>
          <div style={{fontSize:20, fontWeight:800, color:'var(--accent)'}}>{name}</div>
          <div style={{color:'var(--accent-2)', fontWeight:700}}>{title}</div>
          <div style={{color:'var(--muted)'}}>{contact}</div>
        </div>
        <div style={{textAlign:'right'}}>
          <div className="badge">Creative</div>
        </div>
      </div>
      <hr style={{margin:'12px 0'}}/>
      <section><h3 style={{margin:'6px 0'}}>Summary</h3><p style={{marginTop:0}}>{summary}</p></section>
      <section style={{marginTop:8}}><h3 style={{margin:'6px 0'}}>Experience</h3>{experiences.map((e,i)=>(<div key={i} style={{marginBottom:8}}><div style={{fontWeight:700}}>{e.title} <span style={{fontWeight:400,color:'#666'}}>— {e.company}</span></div><ul>{e.bullets.map((b,idx)=>(<li key={idx}>{b}</li>))}</ul></div>))}</section>
      <section style={{marginTop:8}}><h3 style={{margin:'6px 0'}}>Projects</h3>{projects.map((p,i)=>(<div key={i}><div style={{fontWeight:700}}>{p.name}</div><div>{p.desc}</div></div>))}</section>
      <section style={{marginTop:8}}><h3 style={{margin:'6px 0'}}>Skills</h3><div>{(skills||'').split(',').map((s,i)=>(<span key={i} style={{display:'inline-block',background:'var(--accent)',color:'#fff',padding:'6px 8px',borderRadius:20,marginRight:6}}>{s.trim()}</span>))}</div></section>
    </div>
  )
}
