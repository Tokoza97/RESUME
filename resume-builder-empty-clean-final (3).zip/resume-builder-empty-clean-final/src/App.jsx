import React, { useEffect, useState } from 'react'
import Builder from './components/Builder'

export default function App(){
  const [theme, setTheme] = useState('light')

  useEffect(()=>{
    if(theme === 'light') document.documentElement.removeAttribute('data-theme')
    else document.documentElement.setAttribute('data-theme', theme)
  },[theme])

  return (
    <div className="container">
      <div className="header">
        <div>
          <div className="title">RESUME</div>
          <div className="small"></div>
        </div>
        <div className="controls no-print">
          <select className="input" value={theme} onChange={e=>setTheme(e.target.value)}>
            <option value="light">Professional</option>
            <option value="modern">Modern</option>
            <option value="dark">Dark</option>
          </select>
          <button className="btn btn-primary" onClick={()=>window.alert('This is a demo build')}>Help</button>
        </div>
      </div>

      <div>
        <Builder defaultTemplate="creative" />
      </div>
    </div>
  )
}
